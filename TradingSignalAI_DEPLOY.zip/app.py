import os
from datetime import datetime, timedelta, timezone

import pandas as pd
import streamlit as st

from data_engine import forex_crypto_bars, active_futures, futures_bars
from engine import mtf
from journal import log

ASSETS = {
    "EUR/USD": "C:EURUSD",
    "GBP/USD": "C:GBPUSD",
    "USD/JPY": "C:USDJPY",
    "BTC/USD": "X:BTCUSD",
    "ETH/USD": "X:ETHUSD",
}
FUTURES = {"Gold": "GC", "WTI": "CL"}
TIMEFRAMES = [("15m", 15, "minute"), ("1H", 1, "hour"), ("4H", 4, "hour")]

st.set_page_config(page_title="TradingSignalAI REAL v3", page_icon="📈", layout="wide")
st.title("TradingSignalAI — REAL v3")
st.caption("Analisi automatica multi-timeframe · PAPER TRADING · nessun ordine reale")


def _col(df, *names):
    for name in names:
        if name in df.columns:
            return name
    return None


def select_futures_contract(product_code):
    """Seleziona il contratto attivo più liquido, privilegiando scadenze vicine."""
    d = active_futures(product_code)
    if d is None or d.empty:
        raise RuntimeError(f"Nessun contratto futures attivo trovato per {product_code}.")

    d = d.copy()
    if "active" in d.columns:
        active = d["active"].astype(str).str.lower().isin(["true", "1", "yes"])
        if active.any():
            d = d[active]

    ticker_col = _col(d, "ticker", "symbol")
    if not ticker_col:
        raise RuntimeError("L'API futures non ha restituito il ticker del contratto.")
    d = d[d[ticker_col].notna()].copy()

    dte_col = _col(d, "days_to_maturity", "days_to_expiration", "dte")
    if dte_col:
        d["_dte"] = pd.to_numeric(d[dte_col], errors="coerce")
    else:
        date_col = _col(d, "last_trade_date", "expiration_date", "settlement_date")
        if date_col:
            dates = pd.to_datetime(d[date_col], errors="coerce", utc=True)
            now = pd.Timestamp.now(tz="UTC")
            d["_dte"] = (dates - now).dt.total_seconds() / 86400
        else:
            d["_dte"] = 9999

    liq_col = _col(d, "dollar_volume", "volume", "avg_volume", "liquidity")
    d["_liq"] = pd.to_numeric(d[liq_col], errors="coerce").fillna(0) if liq_col else 0.0
    d = d[d["_dte"].fillna(9999) >= 0].copy()
    if d.empty:
        raise RuntimeError(f"Nessun contratto {product_code} con scadenza valida.")

    # Preferiamo i contratti entro ~120 giorni; dentro quel gruppo vince la liquidità.
    preferred = d[d["_dte"] <= 120].copy()
    pool = preferred if not preferred.empty else d.copy()
    max_liq = float(pool["_liq"].max()) if len(pool) else 0.0
    pool["_liq_score"] = pool["_liq"] / max_liq if max_liq > 0 else 0.0
    pool["_score"] = pool["_liq_score"] * 100 - pool["_dte"].clip(lower=0) * 0.15
    row = pool.sort_values("_score", ascending=False).iloc[0]

    return {
        "ticker": str(row[ticker_col]),
        "dte": round(float(row["_dte"]), 1) if pd.notna(row["_dte"]) else None,
        "liquidity": float(row["_liq"]),
    }


def scan_futures(product_code, days=45):
    contract = select_futures_contract(product_code)
    end = datetime.now(timezone.utc)
    start = end - timedelta(days=days)
    frames, errors = {}, {}

    # Massive Futures REST usa una risoluzione direttamente espressa come 15m/1h/4h.
    for tf in ("15m", "1h", "4h"):
        try:
            frames[tf] = futures_bars(
                contract["ticker"],
                resolution=tf,
                start=start.isoformat().replace("+00:00", "Z"),
                limit=50000,
            )
        except Exception as exc:
            errors[tf] = str(exc)

    # Il motore si aspetta le chiavi 15m/1H/4H.
    mapped = {"15m": frames.get("15m", pd.DataFrame()),
              "1H": frames.get("1h", pd.DataFrame()),
              "4H": frames.get("4h", pd.DataFrame())}
    usable = {tf: df for tf, df in mapped.items() if df is not None and not df.empty}
    if not usable:
        msg = "Nessun dato futures ricevuto."
        if errors:
            msg += " | " + " | ".join(f"{k}: {v}" for k, v in errors.items())
        raise RuntimeError(msg)

    return contract, mapped, errors


def show_result(r):
    a, b, c = st.columns(3)
    a.metric("SEGNALE", r["signal"])
    b.metric("SCORE", r["score"])
    c.metric("TF BUY", r.get("buy_tf", 0))
    rows = [{"TF": tf, **v} for tf, v in r["frames"].items()]
    st.dataframe(pd.DataFrame(rows), use_container_width=True)


def log_signal(asset, r):
    if r["signal"] == "WAIT":
        return
    v = r["frames"].get("15m") or next(iter(r["frames"].values()))
    log({
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "asset": asset,
        "signal": r["signal"],
        "score": r["score"],
        "entry": v.get("entry"), "sl": v.get("sl"),
        "tp1": v.get("tp1"), "tp2": v.get("tp2"),
        "rr": v.get("rr"), "reason": v.get("reason"),
    })
    st.success("Segnale registrato nello storico locale (paper trading).")


# --- FX / Crypto -----------------------------------------------------------
st.header("Mercati FX / Crypto")
asset = st.selectbox("Mercato", list(ASSETS))
if st.button("SCANSIONA FX / CRYPTO", type="primary"):
    end = datetime.now(timezone.utc).date()
    start = end - timedelta(days=45)
    frames, errors = {}, {}
    for tf, mult, unit in TIMEFRAMES:
        try:
            frames[tf] = forex_crypto_bars(ASSETS[asset], mult, unit, str(start), str(end))
        except Exception as exc:
            errors[tf] = str(exc)
    if errors:
        st.warning(" | ".join(f"{k}: {v}" for k, v in errors.items()))
    if frames:
        result = mtf(frames)
        show_result(result)
        log_signal(asset, result)

st.divider()

# --- Futures ---------------------------------------------------------------
st.header("Futures — Gold / WTI")
st.caption("Il contratto viene scelto automaticamente tra quelli attivi, privilegiando liquidità e scadenza. Solo analisi/paper trading.")
future_name = st.selectbox("Futures", list(FUTURES))
if st.button("SCANSIONA FUTURES", type="primary"):
    try:
        contract, frames, errors = scan_futures(FUTURES[future_name])
        m1, m2, m3 = st.columns(3)
        m1.metric("CONTRATTO", contract["ticker"])
        m2.metric("DTE", contract["dte"] if contract["dte"] is not None else "—")
        m3.metric("LIQUIDITÀ", f'{contract["liquidity"]:,.0f}')
        if errors:
            st.warning(" | ".join(f"{k}: {v}" for k, v in errors.items()))
        usable = {k: v for k, v in frames.items() if not v.empty}
        if usable:
            result = mtf(usable)
            show_result(result)
            log_signal(f"{future_name} ({contract['ticker']})", result)
    except Exception as exc:
        st.error(f"Errore futures: {exc}")

st.divider()
st.info("Per pubblicare questa app su Streamlit Community Cloud: carica il progetto su GitHub e imposta MASSIVE_API_KEY nei Secrets. Non inserire mai la chiave nel codice o nel repository.")
