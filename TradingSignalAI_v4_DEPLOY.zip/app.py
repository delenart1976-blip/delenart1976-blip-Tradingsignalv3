import io, os
from datetime import datetime, timedelta, timezone
import pandas as pd
import streamlit as st

from data_engine import forex_crypto_bars, active_futures, futures_bars
from engine import mtf, risk_plan, backtest
from journal import log, read_journal, clear_journal

ASSETS = {
    "EUR/USD": "C:EURUSD",
    "GBP/USD": "C:GBPUSD",
    "USD/JPY": "C:USDJPY",
    "BTC/USD": "X:BTCUSD",
    "ETH/USD": "X:ETHUSD",
}
FUTURES = {"Gold": "GC", "WTI": "CL"}

st.set_page_config(page_title="TradingSignalAI v4", page_icon="📈", layout="wide")
st.title("TradingSignalAI — v4")
st.caption("Multi-timeframe signals • Risk Engine • Futures • Backtest • Paper Trading")
st.warning("PAPER TRADING ONLY — questa versione non invia ordini reali.")

with st.sidebar:
    st.header("⚙️ Impostazioni")
    capital = st.number_input("Capitale paper (€)", min_value=100.0, value=10000.0, step=500.0)
    risk_pct = st.number_input("Rischio per trade (%)", min_value=0.05, max_value=5.0, value=0.50, step=0.05)
    min_score = st.slider("Score minimo operativo", 70, 95, 85)
    st.divider()
    st.write("API: " + ("✅ configurata" if os.getenv("MASSIVE_API_KEY") else "🔐 usa Streamlit Secrets"))

def scan_market(label, ticker, days=45):
    end = datetime.now(timezone.utc).date()
    start = end - timedelta(days=days)
    frames, errors = {}, {}
    for tf, mult, unit in [("15m",15,"minute"),("1H",1,"hour"),("4H",4,"hour")]:
        try:
            frames[tf] = forex_crypto_bars(ticker, mult, unit, str(start), str(end))
        except Exception as exc:
            errors[tf] = str(exc)
    if errors:
        st.error(" | ".join(f"{k}: {v}" for k,v in errors.items()))
        return
    if not frames or all(df.empty for df in frames.values()):
        st.error("Nessun dato disponibile.")
        return
    result = mtf(frames, min_score=min_score)
    st.session_state["last_result"] = result
    st.session_state["last_asset"] = label
    show_result(result, label)

def show_result(result, label):
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("SEGNALE", result["signal"])
    c2.metric("SCORE", result["score"])
    c3.metric("BUY TF", result["buy_tf"])
    c4.metric("SELL TF", result["sell_tf"])
    if result["signal"] != "WAIT":
        v = result["frames"]["15m"]
        rp = risk_plan(v, capital, risk_pct)
        st.subheader("🎯 Piano operativo paper")
        a,b,c,d,e = st.columns(5)
        a.metric("Entry", f"{v['entry']:.6g}")
        b.metric("Stop Loss", f"{v['sl']:.6g}")
        c.metric("TP1", f"{v['tp1']:.6g}")
        d.metric("TP2", f"{v['tp2']:.6g}")
        e.metric("R:R", f"{v['rr']:.2f}")
        st.info(f"Rischio massimo: €{rp['risk_amount']:.2f} • Quantità indicativa: {rp['quantity']:.6g}")
        log({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "asset": label, "signal": result["signal"], "score": result["score"],
            "entry": v.get("entry"), "sl": v.get("sl"), "tp1": v.get("tp1"),
            "tp2": v.get("tp2"), "rr": v.get("rr"), "reason": v.get("reason")
        })
    else:
        st.info("WAIT: il sistema non forza un ingresso.")
    rows = [{"TF":tf, **v} for tf,v in result["frames"].items()]
    st.dataframe(pd.DataFrame(rows), use_container_width=True)

tab1, tab2, tab3, tab4 = st.tabs(["📊 Scanner", "🥇 Futures", "🧪 Backtest", "📒 Paper Journal"])

with tab1:
    st.subheader("Forex / Crypto")
    asset = st.selectbox("Mercato", list(ASSETS))
    if st.button("SCANSIONA ORA", type="primary"):
        scan_market(asset, ASSETS[asset])

with tab2:
    st.subheader("Futures — Gold / WTI")
    future_name = st.selectbox("Futures", list(FUTURES))
    if st.button("SCANSIONA FUTURES", type="primary"):
        try:
            contracts = active_futures(FUTURES[future_name])
            if contracts.empty:
                raise RuntimeError("Nessun contratto futures disponibile.")
            contract = contracts.iloc[0]
            ticker_col = next((c for c in ["ticker","contract","symbol"] if c in contracts.columns), None)
            if not ticker_col:
                raise RuntimeError("La risposta futures non contiene ticker/contract/symbol.")
            ticker = str(contract[ticker_col])
            frames = {}
            end = datetime.now(timezone.utc).date()
            start = end - timedelta(days=45)
            for tf, resolution in [("15m","15m"),("1H","1h"),("4H","4h")]:
                frames[tf] = futures_bars(ticker, resolution, str(start), str(end))
            result = mtf(frames, min_score=min_score)
            st.session_state["last_result"] = result
            st.session_state["last_asset"] = f"{future_name} ({ticker})"
            st.success(f"Contratto selezionato: {ticker}")
            show_result(result, f"{future_name} ({ticker})")
        except Exception as exc:
            st.error(f"Errore futures: {exc}")

with tab3:
    st.subheader("Backtest della strategia")
    bt_asset = st.selectbox("Mercato backtest", list(ASSETS), key="bt_asset")
    days = st.slider("Giorni storici", 10, 90, 45)
    if st.button("AVVIA BACKTEST"):
        try:
            end = datetime.now(timezone.utc).date()
            start = end - timedelta(days=days)
            df = forex_crypto_bars(ASSETS[bt_asset], 15, "minute", str(start), str(end))
            result = backtest(df, capital=capital, risk_pct=risk_pct, min_score=min_score)
            st.session_state["backtest"] = result
        except Exception as exc:
            st.error(f"Errore backtest: {exc}")
    if "backtest" in st.session_state:
        r = st.session_state["backtest"]
        a,b,c,d = st.columns(4)
        a.metric("Capitale finale", f"€{r['final_capital']:.2f}")
        a = b; a.metric("Trade", r["trades"])
        c.metric("Win rate", f"{r['win_rate']:.1f}%")
        d.metric("Max drawdown", f"{r['max_drawdown_pct']:.1f}%")
        st.dataframe(pd.DataFrame(r["trades_log"]), use_container_width=True)
        st.caption("Il backtest è una simulazione: non garantisce risultati futuri.")

with tab4:
    st.subheader("Storico segnali paper")
    if st.button("AGGIORNA STORICO"):
        pass
    journal = read_journal()
    if journal.empty:
        st.info("Nessun segnale registrato.")
    else:
        st.dataframe(journal.tail(200), use_container_width=True)
        st.download_button("⬇️ Scarica CSV", journal.to_csv(index=False).encode("utf-8"), "tradingsignalai_paper.csv", "text/csv")
        if st.button("CANCELLA STORICO"):
            clear_journal()
            st.rerun()
