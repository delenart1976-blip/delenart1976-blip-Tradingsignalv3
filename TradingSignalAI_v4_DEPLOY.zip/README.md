# TradingSignalAI v4

Evoluzione della v3 esistente.

## Funzioni
- Forex + Crypto multi-timeframe 15m / 1H / 4H
- Futures Gold / WTI
- Risk Engine con rischio % per trade
- Backtest
- Paper Journal
- Nessuna esecuzione ordini reali

## Streamlit Secrets
Inserire nei Secrets:

MASSIVE_API_KEY = "LA_TUA_NUOVA_CHIAVE"

Non inserire mai la chiave nel codice o in GitHub.
