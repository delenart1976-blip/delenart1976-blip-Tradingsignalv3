import numpy as np
import pandas as pd

def add_indicators(d):
    x = d.copy()
    if x.empty: return x
    for c in ["open","high","low","close","volume"]:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    x = x.dropna(subset=["open","high","low","close"]).copy()
    if "volume" not in x: x["volume"] = 0.0
    x["ema20"] = x.close.ewm(span=20, adjust=False).mean()
    x["ema50"] = x.close.ewm(span=50, adjust=False).mean()
    x["ema200"] = x.close.ewm(span=200, adjust=False).mean()
    delta = x.close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
    x["rsi"] = 100 - 100/(1 + gain/loss.replace(0,np.nan))
    prev = x.close.shift()
    tr = pd.concat([x.high-x.low,(x.high-prev).abs(),(x.low-prev).abs()],axis=1).max(axis=1)
    x["atr"] = tr.ewm(alpha=1/14, adjust=False).mean()
    macd = x.close.ewm(span=12, adjust=False).mean()-x.close.ewm(span=26, adjust=False).mean()
    x["macd_hist"] = macd-macd.ewm(span=9, adjust=False).mean()
    up, dn = x.high.diff(), -x.low.diff()
    plus = np.where((up>dn)&(up>0),up,0)
    minus = np.where((dn>up)&(dn>0),dn,0)
    p = pd.Series(plus,index=x.index).ewm(alpha=1/14,adjust=False).mean()
    m = pd.Series(minus,index=x.index).ewm(alpha=1/14,adjust=False).mean()
    pdi = 100*p/x.atr.replace(0,np.nan); mdi = 100*m/x.atr.replace(0,np.nan)
    dx = 100*(pdi-mdi).abs()/(pdi+mdi).replace(0,np.nan)
    x["adx"] = dx.ewm(alpha=1/14,adjust=False).mean()
    x["res"] = x.high.rolling(20).max().shift(1)
    x["sup"] = x.low.rolling(20).min().shift(1)
    x["vol_ma"] = x.volume.rolling(20).mean()
    return x.replace([np.inf,-np.inf],np.nan).dropna().reset_index(drop=True)

def score(d):
    x = add_indicators(d)
    if len(x) < 20:
        return {"signal":"WAIT","score":0,"entry":None,"sl":None,"tp1":None,"tp2":None,"rr":None,"reason":"Dati insufficienti"}
    r=x.iloc[-1]; s=50; reasons=[]
    if r.ema20>r.ema50>r.ema200: s+=25; reasons.append("trend rialzista")
    elif r.ema20<r.ema50<r.ema200: s-=25; reasons.append("trend ribassista")
    if r.rsi>=55 and r.macd_hist>0: s+=15; reasons.append("momentum rialzista")
    elif r.rsi<=45 and r.macd_hist<0: s-=15; reasons.append("momentum ribassista")
    if r.close>r.res: s+=15; reasons.append("breakout")
    elif r.close<r.sup: s-=15; reasons.append("breakdown")
    if r.adx>=20: reasons.append("ADX conferma trend")
    if r.volume>r.vol_ma: s += 5 if r.close>=r.open else -5; reasons.append("volume sopra media")
    if abs(r.close-r.ema20)>2*r.atr: s-=5; reasons.append("prezzo esteso")
    s=int(np.clip(s,0,100))
    side = "BUY" if s>=85 and r.close>r.ema50 else "SELL" if s>=85 and r.close<r.ema50 else "WAIT"
    if side=="BUY":
        entry=float(r.close); sl=entry-1.5*r.atr; tp1=entry+1.5*r.atr; tp2=entry+3*r.atr
    elif side=="SELL":
        entry=float(r.close); sl=entry+1.5*r.atr; tp1=entry-1.5*r.atr; tp2=entry-3*r.atr
    else:
        entry=sl=tp1=tp2=None
    return {"signal":side,"score":s,"entry":entry,"sl":sl,"tp1":tp1,"tp2":tp2,
            "rr":2.0 if side!="WAIT" else None,"reason":"; ".join(reasons)}

def mtf(frames, min_score=85):
    vals={tf:score(df) for tf,df in frames.items()}
    good=[v for v in vals.values() if v.get("score",0)>0]
    avg=round(sum(v["score"] for v in good)/len(good),1) if good else 0
    buys=sum(v["signal"]=="BUY" for v in good); sells=sum(v["signal"]=="SELL" for v in good)
    final="BUY" if avg>=min_score and buys>=2 else "SELL" if avg>=min_score and sells>=2 else "WAIT"
    return {"signal":final,"score":avg,"buy_tf":buys,"sell_tf":sells,"frames":vals}

def risk_plan(signal, capital, risk_pct):
    entry, sl = signal.get("entry"), signal.get("sl")
    risk_amount = float(capital) * float(risk_pct) / 100
    distance = abs(float(entry)-float(sl)) if entry is not None and sl is not None else 0
    qty = risk_amount/distance if distance > 0 else 0
    return {"risk_amount":risk_amount,"stop_distance":distance,"quantity":qty}

def backtest(df, capital=10000, risk_pct=0.5, min_score=85):
    x = add_indicators(df)
    if len(x) < 250:
        return {"final_capital":capital,"trades":0,"win_rate":0,"max_drawdown_pct":0,"trades_log":[]}
    equity=float(capital); peak=equity; max_dd=0; wins=0; logs=[]
    # Signal is evaluated on each completed candle; next candle is used for outcome.
    for i in range(220, len(x)-1):
        window=x.iloc[:i+1]
        s=score(window)
        if s["signal"]=="WAIT" or s["score"]<min_score: continue
        entry=float(x.iloc[i+1]["open"])
        sl_dist=abs(float(s["entry"])-float(s["sl"]))
        if sl_dist<=0: continue
        if s["signal"]=="BUY":
            sl=entry-sl_dist; tp=entry+2*sl_dist
            hi=float(x.iloc[i+1]["high"]); lo=float(x.iloc[i+1]["low"])
            if lo<=sl: pnl=-float(equity)*risk_pct/100; outcome="SL"
            elif hi>=tp: pnl=float(equity)*risk_pct/100*2; outcome="TP"
            else: continue
        else:
            sl=entry+sl_dist; tp=entry-2*sl_dist
            hi=float(x.iloc[i+1]["high"]); lo=float(x.iloc[i+1]["low"])
            if hi>=sl: pnl=-float(equity)*risk_pct/100; outcome="SL"
            elif lo<=tp: pnl=float(equity)*risk_pct/100*2; outcome="TP"
            else: continue
        equity += pnl
        if pnl>0: wins+=1
        peak=max(peak,equity); max_dd=max(max_dd,(peak-equity)/peak*100)
        logs.append({"time":str(x.iloc[i+1].get("time","")),"signal":s["signal"],"entry":entry,"outcome":outcome,"pnl":round(pnl,2),"equity":round(equity,2)})
    n=len(logs)
    return {"final_capital":round(equity,2),"trades":n,"win_rate":round(wins/n*100,1) if n else 0,
            "max_drawdown_pct":round(max_dd,1),"trades_log":logs}
